package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private EditText editTextItemId, editTextItemName, editTextQuantity;
    private Button buttonAddItem, buttonUpdateItem, buttonDeleteItem, buttonNextToSms;
    private TextView textViewItems;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        editTextItemId = findViewById(R.id.editTextItemId);
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);

        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        buttonDeleteItem = findViewById(R.id.buttonDeleteItem);
        buttonNextToSms = findViewById(R.id.buttonNextToSms);

        textViewItems = findViewById(R.id.textViewItems);

        databaseHelper = new DatabaseHelper(this);

        displayItems();

        buttonAddItem.setOnClickListener(v -> addItem());
        buttonUpdateItem.setOnClickListener(v -> updateItem());
        buttonDeleteItem.setOnClickListener(v -> deleteItem());

        buttonNextToSms.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    private void addItem() {
        String name = editTextItemName.getText().toString().trim();
        String quantityText = editTextQuantity.getText().toString().trim();

        if (name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = databaseHelper.insertItem(name, quantity);

        if (inserted) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            clearFields();
            displayItems();
        } else {
            Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateItem() {
        String idText = editTextItemId.getText().toString().trim();
        String name = editTextItemName.getText().toString().trim();
        String quantityText = editTextQuantity.getText().toString().trim();

        if (idText.isEmpty() || name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this, "Enter ID, item name, and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int id;
        int quantity;

        try {
            id = Integer.parseInt(idText);
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "ID and quantity must be numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean updated = databaseHelper.updateItem(id, name, quantity);

        if (updated) {
            Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            clearFields();
            displayItems();
        } else {
            Toast.makeText(this, "Update failed. Check item ID.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        String idText = editTextItemId.getText().toString().trim();

        if (idText.isEmpty()) {
            Toast.makeText(this, "Enter item ID to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        int id;

        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Item ID must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean deleted = databaseHelper.deleteItem(id);

        if (deleted) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            clearFields();
            displayItems();
        } else {
            Toast.makeText(this, "Delete failed. Check item ID.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayItems() {
        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.getCount() == 0) {
            textViewItems.setText("No inventory items found.");
            cursor.close();
            return;
        }

        StringBuilder builder = new StringBuilder();

        while (cursor.moveToNext()) {
            builder.append("ID: ").append(cursor.getInt(0))
                    .append(" | ")
                    .append(cursor.getString(1))
                    .append(" | Qty: ")
                    .append(cursor.getInt(2))
                    .append("\n\n");
        }

        textViewItems.setText(builder.toString());
        cursor.close();
    }

    private void clearFields() {
        editTextItemId.setText("");
        editTextItemName.setText("");
        editTextQuantity.setText("");
    }
}