package com.example.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "InventoryPrefs";
    private static final String SMS_ENABLED_KEY = "sms_enabled";

    private SharedPreferences sharedPreferences;
    private Button buttonAllow;
    private Button buttonDeny;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        buttonAllow = findViewById(R.id.buttonAllow);
        buttonDeny = findViewById(R.id.buttonDeny);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        buttonAllow.setOnClickListener(v -> requestSmsPermission());

        buttonDeny.setOnClickListener(v -> {
            saveSmsPreference(false);
            Toast.makeText(this, "SMS disabled. App will continue without notifications.", Toast.LENGTH_LONG).show();
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            saveSmsPreference(true);
            sendLowStockSms();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    private void saveSmsPreference(boolean enabled) {
        sharedPreferences.edit()
                .putBoolean(SMS_ENABLED_KEY, enabled)
                .apply();
    }

    private void sendLowStockSms() {
        boolean smsEnabled = sharedPreferences.getBoolean(SMS_ENABLED_KEY, false);

        if (!smsEnabled) {
            Toast.makeText(this, "SMS notifications are turned off.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();

            String phoneNumber = "1234567890";
            String message = "Inventory Alert: An item is low in stock.";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "SMS could not be sent on this emulator/device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPreference(true);
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                sendLowStockSms();
            } else {
                saveSmsPreference(false);
                Toast.makeText(this, "SMS permission denied. App still works without notifications.", Toast.LENGTH_LONG).show();
            }
        }
    }
}