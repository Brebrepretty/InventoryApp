package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEditItemActivity extends AppCompatActivity {

    EditText etItemName, etCategory, etQuantity;
    Button btnSaveItem, btnCancelItem;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        etItemName = findViewById(R.id.etItemName);
        etCategory = findViewById(R.id.etCategory);
        etQuantity = findViewById(R.id.etQuantity);
        btnSaveItem = findViewById(R.id.btnSaveItem);
        btnCancelItem = findViewById(R.id.btnCancelItem);

        databaseHelper = new DatabaseHelper(this);

        btnSaveItem.setOnClickListener(v -> {
            String itemName = etItemName.getText().toString().trim();
            String category = etCategory.getText().toString().trim();
            String quantityText = etQuantity.getText().toString().trim();

            if (itemName.isEmpty() || category.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(AddEditItemActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityText);

            boolean result = databaseHelper.insertItem(itemName, category, quantity);

            if (result) {
                Toast.makeText(AddEditItemActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(AddEditItemActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancelItem.setOnClickListener(v -> finish());
    }
}
