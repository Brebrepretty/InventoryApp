package com.example.inventoryapp;

public class InventoryItem {

    private int id;
    private String itemName;
    private String category;
    private int quantity;

    public InventoryItem(int id, String itemName, String category, int quantity) {
        this.id = id;
        this.itemName = itemName;
        this.category = category;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategory() {
        return category;
    }

    public int getQuantity() {
        return quantity;
    }
}
