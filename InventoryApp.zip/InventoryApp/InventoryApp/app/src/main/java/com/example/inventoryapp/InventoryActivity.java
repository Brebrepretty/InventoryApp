package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    RecyclerView rvInventory;
    Button btnAddItem, btnLogout;
    DatabaseHelper databaseHelper;
    ArrayList<InventoryItem> itemList;
    InventoryAdapter inventoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        rvInventory = findViewById(R.id.rvInventory);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnLogout = findViewById(R.id.btnLogout);

        databaseHelper = new DatabaseHelper(this);
        itemList = databaseHelper.getAllItems();

        inventoryAdapter = new InventoryAdapter(itemList);
        rvInventory.setLayoutManager(new LinearLayoutManager(this));
        rvInventory.setAdapter(inventoryAdapter);

        btnAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddEditItemActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        itemList.clear();
        itemList.addAll(databaseHelper.getAllItems());
        inventoryAdapter.notifyDataSetChanged();
    }
}
